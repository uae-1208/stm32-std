#ifndef __ADC_H__
#define __ADC_H__


#include "stm32f4xx.h"
void ADC1_Init(void);


#endif

