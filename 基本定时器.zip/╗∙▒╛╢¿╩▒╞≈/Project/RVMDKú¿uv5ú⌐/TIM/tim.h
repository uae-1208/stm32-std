#ifndef __TIM_H__
#define __TIM_H__

#include "stm32f4xx.h"
void TIMx_Configuration(void);



#endif
