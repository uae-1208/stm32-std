#include "stm32f4xx.h"
#include "usart.h"




int main(void)
{
	USART_Config();
	printf("Hello,world!\r\n");	
	while(1)
	{
	}
}

  
  
