#ifndef __KEY_H__
#define __KEY_H__

#include "stm32f4xx.h"
void key_config(void);


#endif 
