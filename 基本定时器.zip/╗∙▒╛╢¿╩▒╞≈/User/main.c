#include "stm32f4xx.h"
#include "gpio.h"
#include "tim.h"

int main(void)
{
    led_config();
	TIMx_Configuration();
	while(1)
	{
		
	}
}



