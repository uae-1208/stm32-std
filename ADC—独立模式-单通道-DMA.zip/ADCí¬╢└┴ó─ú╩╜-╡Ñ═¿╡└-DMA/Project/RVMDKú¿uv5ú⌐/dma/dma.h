#ifndef __DMA_H__
#define __DMA_H__


void DMA_Config(void);


#endif

