#ifndef __EXIT_H__
#define __EXIT_H__

#include "stm32f4xx.h"
void exit_config(void);
void EXIT_NVIC_Configuration(void);

#endif
